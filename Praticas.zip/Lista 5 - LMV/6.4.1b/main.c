#include <stdio.h>
#include <stdlib.h>
#include "rvgs.h"
#include "rngs.h"


int main()
{
    float i, nCara = 0, nCoroa = 0;
    long result;
    PutSeed(-1);
    for(i=0; i<1000 ; i++){
        result = Bernoulli(0.5);
        if(result == 1.0){
            nCara++;
        }
        else
            nCoroa++;
    }
    nCoroa = nCoroa/1000;
    nCara = nCara/1000;

    printf("Frequencia Relativa:\n%f Cara\n%f Coroa", nCara, nCoroa);

}
