#include <stdio.h>
#include <stdlib.h>
#include "rvgs.h"
#include "rngs.h"
#include "rvms.h"

int main()
{
    double n,p,x;
    int i;
    for(i=0;i<11; i++){
        printf("%lf\n", pdfBinomial(10,0.5,i));
    }
}
