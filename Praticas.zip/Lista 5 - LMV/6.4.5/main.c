#include <stdio.h>
#include <stdlib.h>
#include "rvms.h"

int main()
{
    double n,p,x;
    int i;
    printf("Binomial\t\tPoisson\n");
    for(i=0;i<26; i++){
        printf("%lf\t\t%lf\n", pdfBinomial(25,0.04,i), pdfPoisson(1, i));
    }
    return 0;
}
