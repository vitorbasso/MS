#!/usr/bin/gnuplot -persist
do for [i=0:4] {
    set style data histogram
    set style fill pattern 2
    set boxwidth 3
    set terminal 'png'
    set key autotitle columnhead
    outfile = sprintf('histogram-611-%d.png', i)
    infile = sprintf('histogram-611-%d.txt', i)
    set output outfile
    plot [0:15][0:0.24] infile using 2 lc rgb "#78909c"
}