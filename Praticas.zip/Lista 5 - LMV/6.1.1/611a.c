#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rvgs.h"
#include "rngs.h"

#define RANGE 360000

int main() {
    typedef struct hist{
        float media;
        float desvio_padrao;
        float incidencias[13];
        float fr[13];
    } Histograma;
    Histograma hist[6];
    long seed = 0;

    int i, j;
    FILE *f;
    char file_name[] = "histogram-611-X.txt";
    for (i = 0; i < 5; i++) {
        file_name[14] = i + '0';
        f = fopen(file_name, "w");
        sleep(1);
        PutSeed(-1);
        GetSeed(&seed);
        for (j = 0; j < 13; j++){
            hist[i].incidencias[j] = 0;
            hist[i].fr[j] = 0;
        }

        for (j = 1; j <= RANGE; j++) {
            long result = Equilikely(1, 6) + Equilikely(1, 6);
            hist[i].incidencias[result]++;
            /** media de um histograma **/
            hist[i].media = ((hist[i].media * (float)(j-1)) + result)/(float)j;
            float desvio = pow(result - hist[i].media, 2);
            hist[i].desvio_padrao += desvio;
        }

        hist[i].desvio_padrao = sqrt(hist[i].desvio_padrao/RANGE);
        printf("%f\t%f\n", hist[i].media, hist[i].desvio_padrao);

        fprintf(f,"\"Seed: %ld. N: %d. Average: %.4f. SD: %.4f\"\n",
        seed, RANGE,hist[i].media, hist[i].desvio_padrao);

        for (j = 0; j < 13; j++) {
            /** frequencia relativa de um histograma **/
            hist[i].fr[j] = hist[i].incidencias[j]/RANGE;
            fprintf(f, "%d %f\n", j, hist[i].fr[j]);
        }
        fclose(f);
    }
    return 0;
}
