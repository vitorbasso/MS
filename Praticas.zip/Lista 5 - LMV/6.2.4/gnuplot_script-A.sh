#!/usr/bin/gnuplot -persist
set style data histogram
set style fill pattern 2
set boxwidth 3
set terminal 'png'
set key autotitle columnhead
outfile = sprintf('histogram-624-A.png')
infile = sprintf('histogram-624-A.txt')
set output outfile
plot [0:19][0:0.15] infile using 2 lc rgb "#78909c"
