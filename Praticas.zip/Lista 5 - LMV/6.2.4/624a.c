#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "rvgs.h"
#include "rngs.h"
#include "rvms.h"

#define RANGE 1000000
#define M 19

typedef struct hist{
    double media;
    double desvio_padrao;
    double incidencias[M+1];
    double fr[M+1];
} Histograma;

int main() {
    Histograma hist;
    long seed = 0;
    int j;
    FILE *f;
    char file_name[] = "histogram-624-A.txt";
    f = fopen(file_name, "w");
    PutSeed(-1);
    GetSeed(&seed);
    fprintf(f,"\"Semente: %ld com %d elementos\"\n", seed, RANGE);

    for (j = 0; j <= M; j++){
        hist.incidencias[j] = 0;
        hist.fr[j] = 0;
    }

    for (j = 1; j <= RANGE; j++) {
        long result = Poisson(9);
        //fprintf(f, "%d %ld\n", j, result);
        hist.incidencias[result]++;
        /** media de um histograma **/
        hist.media = ((hist.media * (double)(j-1)) + result)/(double)j;
        double desvio = pow(result - hist.media, 2);
        hist.desvio_padrao += desvio;
    }

    for (j = 1; j <= M; j++) {
        /** frequencia relativa de um histograma **/
        hist.fr[j] = hist.incidencias[j]/RANGE;
        fprintf(f, "%d %f\n", j, hist.fr[j]);
    }
    hist.desvio_padrao = sqrt(hist.desvio_padrao/RANGE);
    printf("%f\t%f\n", hist.media, hist.desvio_padrao);
    fclose(f);
    return 0;
}
