#!/usr/bin/gnuplot -persist
set style data histogram
set style fill pattern 2
set terminal 'png'
set key autotitle columnhead
outfile = sprintf('histogram-624-B.png')
set output outfile
infile = sprintf('histogram-624-B-PDF.txt')
infile_pdf = sprintf('histogram-624-B.txt')
plot [0:19][0:0.15] infile using 2 lc rgb "#78909c", infile_pdf using 2 lc rgb "blue"