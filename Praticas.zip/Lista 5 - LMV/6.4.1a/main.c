#include <stdio.h>
#include <stdlib.h>
#include "rvgs.h"
#include "rngs.h"


int main()
{
    int i, nCara = 0, nCoroa = 0;
    long result;
    PutSeed(-1);
    for(i=0; i<10 ; i++){
        result = Bernoulli(0.5);
        if(result == 1.0){
            nCara++;
        }
        else
            nCoroa++;
    }

    printf("%d Caras\n%d Coroas", nCara, nCoroa);

}
