#include <stdlib.h>
#include <stdio.h>
#include "rvms.h"
#include "rvgs.h"
#include "rngs.h"

/* Exercise 6.2.7 (a) Implement Algorithm 6.2.1 for a Poisson(μ) random variable and
use Monte Carlo simulation to verify that the expected number of passes through the while
loop is μ. Use μ = 1, 5, 10, 15, 20, 25. (b) Repeat with Algorithm 6.2.2. (c) Comment. (Use
the function cdfPoisson in the library rvms to generate the Poisson(μ) cdf values.) */

#define SIMULATION 1000000.0

double idf(long a, double u);

int main()
{
    double us[] = {1, 5, 10, 15, 20, 25};
    int i, j;
    double results[] = {0, 0, 0, 0, 0, 0};

    for (j = 0; j < SIMULATION; j++)
    {
        for (i = 0; i < 6; i++)
        {
            results[i] += idfPoisson(us[i], Random());
        }
    }

    // resultados
    for (i = 0; i < 6; i++)
    {
        results[i] = results[i] / SIMULATION;
        printf("%f | MC = %f\n", us[i], results[i]);
    }
    return 0;
}