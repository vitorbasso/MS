#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double t = 1, x = 0, sum = 0;
    long h = 30, v = 2, c_ini = 20, it = 5;

    double p = 0;
    int s = 0, c;

    for (int i = 0; i <= it; i++)
    {
      c = c_ini - i;
      p = (double) h  / (double)(c * v);
      printf("Para c = %d.\n", c);
      if (p == 1) {
        printf("As estatisticas nao existem para p = 1\n");
        continue;
      }
      while(s < c)
      {
        sum += t;
        s++;
        t *= (((double)c) * p / (double)s);
      }

      sum += t / (1.0 - p + 0.00001); /** Somado numero insignificante para remover nota��o de infinito no calculo **/

      double q_barra = (t * p) / ((1.0 - p) * (1.0 - p) * sum);
      double l_barra = q_barra + (((double)c) * p);
      double d_barra = q_barra / (double) h;
      double w_barra = l_barra / (double) h;

      printf(" p ................. = %.2lf\n", p);
      printf(" q_barra ........... = %.2lf\n", q_barra);
      printf(" l_barra ........... = %.2lf\n", l_barra);
      printf(" d_barra ........... = %.2lf\n", d_barra);
      printf(" w_barra ........... = %.2lf\n\n", w_barra);
    }
    return 0;
}
