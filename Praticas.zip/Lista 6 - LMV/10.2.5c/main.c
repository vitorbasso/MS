#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "rvms.h"
#include "rngs.h"
#include "rvgs.h"

#define TIME 1000

double micro(double x, long h, long v, long k)
{
  double micro = 0;
  if (x == k)
  {
    return micro;
  }
  if (x == 0)
  {
    micro = 1.0 / (double)h;
  }
  else
  {
    micro = 1.0 / (double)(h + v);
  }
  return micro;
}

double pe(double x, long h, long v, long k)
{
  double pe = 0.0;
  if (x == k)
  {
    return pe;
  }
  if (x == 0.0)
  {
    pe = 1.0;
  }
  else
  {
    pe = (double)h / (double)(h + v);
  }
  return pe;
}

int main()
{
    double t = 0, mediaNos = 0;
    long h = 3, v = 4, k = 4, it = 0, x = 0;
    int birthrate[50], y, deathrate[50], i;

    for(i = 0; i<50; i++){
        birthrate[i] = 0;
        deathrate[i] = 0;
    }
    PutSeed(-1);

    double countNode[] = { 0.0, 0.0, 0.0, 0.0, 0.0};

    while(t < TIME)
    {
      t += Exponential(micro(x, h, v, k));
      y = (2 * Bernoulli(pe(x, h, v, k))) - 1;

      if(y == -1)
        deathrate[(int)x]++;
      else if(y == 1)
        birthrate[(int)x]++;

      x += y;
      countNode[x] += 1.0;
      mediaNos += x;
      it++;
    }

    printf("Quantidade de servico: %.0f. Com media: %.3f\n", mediaNos, mediaNos/it);
    printf("Media por No:\n Sem servico: %.3f.\n", countNode[0] / it);
    for(i = 1; i <= k; i++)
    {
      printf(" No de servico %d. Media: %.3f\n", i, countNode[i] / it);
    }

    for(i=1; i< k; i++)
        printf("\n\nTaxa %d: %lf\n", i, ((double)birthrate[i]/deathrate[i]));

    return 0;
}


