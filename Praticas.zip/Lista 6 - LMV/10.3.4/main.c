#include <stdio.h>
#include <stdlib.h>
#include "rngs.h"
#include "rvgs.h"

#define T 10000

const static double micro[] = {1.0, 3/2, 2.0, 1/2};
const static double p[4][4] = {{0.0, 0.3, 0.6, 0.1}, {0.0, 0.0, 0.6, 0.4}, {0.0, 0.3, 0.0, 0.7}, {0.4, 0.0, 0.6, 0.0}};

long NextState(long x) {
    double u = Random();
    long next = 0;
    while (p[x][next] <= u) {
        u -= p[x][next];
        next++;
    }
    return next;
}

int main() {
    PutSeed(-1);
    long vector[] = {0, 0, 0, 0};
    
    long t = 0;
    long x = 1;
    double sum = 0.0;

    while (t < T) {
        t += Exponential(micro[x]);
        x = NextState(x);
        vector[x]++;

        sum += x;
    }

    int i = 0;
    for (i = 0; i < 4; i++) {
        printf("Proportion of time in state %d is %0.3lf\n", i, vector[i] / (double) T);
    }

    printf("x/ = %.3lf\n", sum / T);
    return 0;
}