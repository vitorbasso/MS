#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "rvms.h"
#include "rngs.h"
#include "rvgs.h"

// Exercise 10.2.9 Use Algorithm 10.2.1 to
// verify by simulation that the results in
// Theorem 10.2.7 are correct in the case
// c = 4, λ = 8, ν = 2, k = 10.

#define TIME 10

long fatorial(long n)
{
  long fat;
  for (fat = 1; n > 1; n = n - 1)
    fat = fat * n;
  return fat;
}

double f_zero(long c, long k)
{
  double parte1 = pow(c, c) / fatorial(c);
  long parte2 = (k - c + 1);

  long parte3 = 0;
  for (long l = 0; l < c; l++)
  {
    parte3 += pow(c, l) / fatorial(l);
  }
  return pow((parte1 * parte2 + parte3), -1);
}

long func(long l, long c, long k)
{
  if (l <= (c - 1))
  {
    return ((pow(c, l) / fatorial(l)) * f_zero(c, k));
  }
  else
  {
    return ((pow(c, c) / fatorial(l)) * f_zero(c, k));
  }
}

double micro(long h)
{
  return 1.0 / (double) h;
}

int main()
{
  double t = 0, mediaNos = 0;

  long h = 8, v = 2, k = 10, it = 0, c = 4, x = 1;

  //FILE *f;
  //char file_name[] = "data_10_2_9.txt";
  //f = fopen(file_name, "w");

  PutSeed(-1);
  //criarFatoriais(c);

  // COMO SABEMOS QUE P = 1, ENTÃO:

  while (t < TIME)
  {
    t += Exponential(micro(h));
    x += func(x, c, k);
    printf("%0.3f\t%.3ld\n", t, x);
    mediaNos += x;
    it++;
  }

  printf("Media de nos por serviço: %f\n", mediaNos / it);

  return 0;
}