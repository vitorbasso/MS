#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "rvms.h"
#include "rngs.h"
#include "rvgs.h"

#define TIME 1000


double micro(double x, long h, long v)
{
    double micro = 0;
    if (x == 0.0)
    {
        micro = 1.0 / (double)h;
    }
    else
    {
        micro = 1.0 / (double)(h + v);
    }
    printf("x: \t%f | micro: \t%f\n", x, micro);
    return micro;
}

double pe(double x, long h, long v)
{
    double pe = 0.0;
    if (x == 0.0)
    {
        pe = 1.0;
    }
    else
    {
        pe = (double)h / (double)(h + v);
    }
    printf("x: \t%f | pe: \t%f\n", x, pe);
    return pe;
}

int main()
{
    double t = 0, x = 0;
    int max=0, i=0;
    int Birthrate[30], Deathrate[30];

    for(i=0; i<30; i++)
    {
        Birthrate[i] = 0;
        Deathrate[i] = 0;
    }

    long h = 3, v = 4;

    int iteracao = 0, y=0;

    PutSeed(-1);

    while(t < TIME)
    {
        iteracao++;
        printf("Nova rodada. t(%f)\n", t);
        t += Exponential(micro(x, h, v));
        y = (2 * Bernoulli(pe(x, h, v))) - 1;
        if(y == 1)
        {
            Birthrate[(int)x]++;
        }
        else if( y == -1)
        {
            Deathrate[(int)x]++;
        }

        x += y;

        if(x>max)
        {
            max = x;
        }
    }

    printf("\n\n\n");

    for(i=1; i<max; i++)
    {
        printf("Taxas %d: %lf\n ", i, ((double)Birthrate[i]/Deathrate[i]));
    }
    return 0;
}



