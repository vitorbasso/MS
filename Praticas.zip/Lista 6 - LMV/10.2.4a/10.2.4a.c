#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "rvms.h"
#include "rngs.h"
#include "rvgs.h"

#define TIME 100

double micro(double x, long h, long v)
{
  double micro = 0;
  if (x == 0)
  {
    micro = 1.0 / (double)h;
  }
  else
  {
    micro = 1.0 / (double)(h + v);
  }
  printf("x: \t%f | micro: \t%f\n", x, micro);
  return micro;
}

double pe(double x, long h, long v)
{
  double pe = 0.0;
  if (x == 0.0)
  {
    pe = 1.0;
  }
  else
  {
    pe = (double)h / (double)(h + v);
  }
  printf("x: \t%f | pe: \t%f\n", x, pe);
  return pe;
}

int main()
{
    double t = 0, x = 0, time = 10;
    long c = 4, h = 8, v = 2;

    PutSeed(-1);

    while(t < TIME)
    {
      printf("Nova rodada. t(%f)\n", t);
      t += Exponential(micro(x, h, v));
      x += (2 * Bernoulli(pe(x, h, v))) - 1;
    }
    return 0;
}



