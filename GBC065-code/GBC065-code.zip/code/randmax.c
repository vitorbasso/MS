#include <stdio.h>
#include <stdlib.h>

void main(){
  printf("\n%d\n",RAND_MAX);
}
